Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - danglada ( https://freesound.org/people/danglada/ )

You can find this pack online at: https://freesound.org/people/danglada/packs/1011/

License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/


Sounds in this pack
-------------------

  * 17573__danglada__G_Major.wav
    * url: https://freesound.org/s/17573/
    * license: Sampling+
  * 17572__danglada__F_Major.wav
    * url: https://freesound.org/s/17572/
    * license: Sampling+
  * 17571__danglada__E_Major.wav
    * url: https://freesound.org/s/17571/
    * license: Sampling+
  * 17570__danglada__D_Major.wav
    * url: https://freesound.org/s/17570/
    * license: Sampling+
  * 17569__danglada__C_Major.wav
    * url: https://freesound.org/s/17569/
    * license: Sampling+
  * 17568__danglada__B_Major.wav
    * url: https://freesound.org/s/17568/
    * license: Sampling+
  * 17567__danglada__A_Major.wav
    * url: https://freesound.org/s/17567/
    * license: Sampling+


