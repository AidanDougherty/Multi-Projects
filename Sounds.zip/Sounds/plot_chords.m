

ddir='/Users/AidanDougherty1/Desktop/Multi Project/Sounds/1011__danglada__guitar-major-chords';

D=dir(ddir);


close all;

ctr=0;

openstrings = [ 82.41 110 146.8 196 246.9 329.6];
gchord= [ 98	123.5	146.8	196	246.9	392 ];
achord=[    	110	164.8	220	277.2	329.6];


for jj=1:length(D)
    
    if ( length(D(jj).name)<3)
        continue;
    end
    if ( contains(D(jj).name,'txt'))
        continue;
    end
    
    ctr=ctr+1;
    
    
  Ns=100000;  
  n1=40000;
  n2=n1+Ns;
  
    % Read an audio waveform
    [d,sr] = audioread([D(jj).folder '/' D(jj).name],[n1 n2]);
    % Plot the spectrogram

    N=length(d(:,1));
    t=(0:N-1)/sr;

    figure(ctr);
    subplot(2,1,1)
    plot(t,d(:,1),t,d(:,2))
    grid on
    title(D(jj).name);
    
    M=2^17;
    [S1,f1]=fftmode(t,d(:,1),M);
    [S2,f2]=fftmode(t,d(:,2),M);

    subplot(2,1,2);

    plot(f2, dB(abs(S2).^2))
    axis([0 500 min( dB(abs(S1).^2))-10 max( dB(abs(S1).^2))+3])
    plotXmarks(openstrings,'k--');
    if ( contains(D(jj).name,'g-major'))
        plotXmarks(gchord,'r--');
    end
     if ( contains(D(jj).name,'a-major'))
        plotXmarks(achord,'r--');
    end
    grid on

end