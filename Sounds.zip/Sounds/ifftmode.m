function [h,x]=ifftmode(f,H,M)
%return h(x)
%f,H use M points (power of 2)
%do ifft the undap to get x h
%x is M points from xmin to xmax (get from .fld file)
%
%
meven=(M/2==floor(M/2));
N=length(f);
df=f(2)-f(1);
dx=1/(N*df);

if (~meven)
	hh=fftshift(ifft(fftshift(H)));
   xx=f*(dx/df);
   
   x=xx( (N-M+1)/2+1 : (N+M-1)/2+1 );
   h=hh( (N-M+1)/2+1 : (N+M-1)/2+1 );
else
   hh=fftshift(ifft(fftshift(H.*exp(1i*2*pi*f*dx/2) )));
	xx=f*(dx/df)+dx/2;
   
   x=xx( (N-M)/2+1 : (N+M)/2 );
   h=hh( (N-M)/2+1 : (N+M)/2 );
end

	%h=h*sqrt(N);  %if you want sum(|h|^2)=1
    h=h/dx;
    %h=h/sqrt(N*dx);
    %disp(['h ->' num2str(sum(abs(h).^2)*dx)] );
%disp('poop')
