


toff=0.5;
T=0.010;  Tp=0.1;

chstr=['Gauss_T' num2str(T*1000) '_ms'];


N=2048*64;

dt=1/44100;
t=[0:dt:(N-1)*dt]';



S=  exp( -0.5*((t-toff)/T).^2);

[FS,f]= fftmode(t,S,N);



figure(99)

subplot(2,1,1);
plot(t,S,'b.-'); grid on
xlabel('time (sec)')
axis([toff-4*Tp toff+4*Tp -1.1 1.1]);
title(UnderlineToDash(chstr));

subplot(2,1,2)
plot(f, abs(FS).^2,'r.-');
grid on
axis([-1000 1000 0 max(abs(FS).^2)]);
xlabel('Frequency (Hz)');

d=S*1;
fnout=[ chstr '.wav'];
audiowrite(fnout,d,1/dt);