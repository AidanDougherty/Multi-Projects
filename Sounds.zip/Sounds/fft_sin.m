
N=2048*64;

dt=1/44100;
t=[0:dt:(N-1)*dt]';

fA =440;

T = sin(2*pi*fA*t);
T2 = T.*(T>0)+ (0.0*T).*(T<0);

[FT,f]= fftmode(t,T,N);
[FT2,f2]= fftmode(t,T2,N);


figure(99)

subplot(2,1,1);
plot(t,T); grid on
xlabel('t')
axis([0 max(t) -1.1 1.1]);

subplot(2,1,2)
%plot(f, imag(FT),'b.-',f2,imag(FT2),'r.-');
plot(f, imag(FT),'b.-');

grid on

axis([-1000 1000 -1 1]);

d=T*0.5;
fnout='A_note.wav';
audiowrite(fnout,d,1/dt);