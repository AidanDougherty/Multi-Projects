

gchord= [ 98	123.5	146.8	196	246.9	392 ];
achord=[    	110	164.8	220	277.2	329.6];



mychord=achord;
chstr='A chord';

mychord=gchord;
chstr='G chord';


N=2048*64;

dt=1/44100;
t=[0:dt:(N-1)*dt]';

t1=0.1; t2=1.0; ton=0.5;

Dnramp= exp(-(t-ton)/t2).*(t>ton)   +(t<=ton);
Env= (1-exp(-t./t1)).*Dnramp;

T=zeros(size(t));
for jj=1:length(mychord)
  fA =mychord(jj);

  T = T+sin(2*pi*fA*t);%+sin(2*pi*2*fA*t)+sin(2*pi*4*fA*t);
end

T=T/max(T);

%T=T.*Env;

[FT,f]= fftmode(t,T,N);

bw=130;
fcent=200;
notch = 1- ( (abs(f-fcent)<bw/2) + (abs(f+fcent)<bw/2) );

FFS = FT.*notch;

[Sfilt,tfilt]=ifftmode(f,FFS,N);

Sfilt=real(Sfilt)/max(abs(Sfilt));

figure(99)

subplot(2,1,1);
plot(t,T,'b-'); grid on
xlabel('t')
axis([0 max(t) -1.1 1.1]);
title(chstr);

subplot(2,1,2)
plot(f, abs(FT).^2,'r.-', f,abs(FFS).^2,'g');
grid on
axis([-1000 1000 0 max(abs(FT).^2)]);
xlabel('Frequency (Hz)');
d=T*1;
fnout=[ chstr '.wav'];




sound(Sfilt, 1/dt)

audiowrite(fnout,d,1/dt);