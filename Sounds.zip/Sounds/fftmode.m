function [H,f,hh,xx]=fftmode(x,h,N)
%[H,f,hh,xx]=fftmode(x,h,N)
%return H(k) and freq axis
%use N points (power of 2)
%pads x,h as necessary
%set up so if length(x) is odd x==0 is 
%expected to be included.
%if length(x) is even, then [...., -1/2 , 1/2 ...]
%
%either way peak of H(f) is at f=0.
%needed to 'untimeshift' for M=even to get H real.


M=length(x);
meven=(M/2==floor(M/2));

if (meven)
  dx=abs(x(M/2+1)-x(M/2));  % take dx from middle of array
else
  dx=  abs(x( (M-1)/2+1)-x((M-1)/2));
end

df=1/(N*dx);

   D=N-M;
   z1=zeros([ceil(D/2) 1]);
   z2=zeros([floor(D/2) 1]);
   hh=[z1;h;z2];
   xx=[1:N]'*dx-N/2*dx-dx/2*meven-dx*(~meven);
   
   xx=xx+mean(x);
   
f=[ -(N/2):(N/2-1)]'*df; 
   
H=fftshift(fft(fftshift(hh)));
H=H.*exp(-1i*2*pi*f*dx/2*meven);

%H=H/sqrt(N); %if you want sum(|H|^2)=1

H=H/N/df;
%H=H/sqrt(N*df);

%disp(['H ->' num2str(sum(abs(H).^2)*df)] );

   
   







