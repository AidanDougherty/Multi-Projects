close all


ddir='/Users/AidanDougherty1/Desktop/Multi Project/Sounds/';

fn = 'Yamaha-V50-Synbass-1-C2.wav';
%fn='Alesis-Fusion-Acoustic-Bass-C2.wav';
fn='Alesis-Fusion-Viola-C5.wav';
% fn='Closed-Hi-Hat-1.wav';
 fn = 'F_Guitar_Chord.m4a';
% fn='E-Mu-Proteus-FX-Wacky-Snare.wav'
% %fn='Alesis-Fusion-Nylon-String-Guitar-C4.wav'
fNote = 174.6;
aNote = 220;
cNote = 261.6;
fFreq = horzcat(1, (fNote:fNote:5*fNote), (aNote:aNote:5*aNote),(cNote:cNote: 5*cNote));




% Read an audio waveform
[d,sr] = audioread([ddir fn]);
% Plot the spectrogram



N=length(d(:,1));
t=[0:N-1]/sr;

% fnote=440;
% samp=0;
% Tnote(:,1)=samp*cos(2*pi*fnote*t);
% Tnote(:,2)=samp*sin(2*pi*fnote*t);
% d=Tnote;
%plot(t,d(:,1),t,d(:,2))
figure(1)

plot(t, d(:,1))
title('F Guitar Chord Waveform')
ylabel('Amplitude')
xlabel('time (seconds)')
M=2^18;

[S1,f1]=fftmode(t,d(:,1),M);




figure(99)
plot(f1, (S1))
% plot(f1, dB(abs(S1).^2))
% axis([0 500 min( dB(abs(S1).^2))-10 max( dB(abs(S1).^2))+3])
title('F Guitar Chord Transform')
ylabel('Amplitude')
xlabel('Frequency (Hz)')
% plotXmarks(fFreq, 'r--')
% hold on
% plot(fFreq, 0.01, 'r*')

figure(2)
[nr, nc] = size(d);

namp=0.14;
dNoise = d + namp*rand(nr,nc)-namp/2;

dNoise=dNoise/max(max(abs(dNoise)));

plot(t, dNoise(:,1))
title('F Guitar Chord + Noise')
ylabel('Amplitude')
xlabel('Time (seconds)')


figure(3)
[S2,f2]=fftmode(t,dNoise(:,2),M);
semilogy(f2, abs(S2).^2)
title('F Guitar Chord + Noise Transform')
ylabel('Amplitude')
xlabel('Frequency (Hz)')

fmax = 4000;
[f2nr, f2nc] = size(f2);
filter = zeros(f2nr, f2nc);
i=1;
while i < f2nr
    if(abs(f2(i))<fmax)
        filter(i) = 1;
    end
    i=i+1;
end

%filter= ones(size(f2)).*( abs(f2)<fmax);

% figure(4)
% plot(f2, filter)

figure(5)
dFilter = filter.*S2;
plot(f2, dFilter)
title('F Guitar Chord + Noise Transform Filtered')
ylabel('Amplitude')
xlabel('Frequency (Hz)')

[Tf,t3]  = ifftmode(f2, dFilter(:,1), M);
Tf = real(Tf)/max(real(Tf));
figure(6)
plot(t3, Tf)
title('Filtered F Guitar Chord + Noise')
ylabel('Amplitude')
xlabel('Time (seconds)')

sound(d, sr)
pause(5)
sound(dNoise, sr)
pause(5)
sound(Tf, sr)


fnout='fmajNoise.wav';
audiowrite(fnout,dNoise,sr);

fnout = 'fmajFiltered.wav';
audiowrite(fnout, Tf, sr);
%subplot(311)
%specgram(d(:,1),1024,sr);


% % Read in a different format
% [d2,sr] = audioread('piano.mp3');
% subplot(312)
% specgram(d2(:,1),1024,sr);
% % Read with resampling, casting to mono, and time limits
% forcemono = 1;
% starttime = 0.5;  % seconds
% duration = 1.0;
% targetsr = 16000;
% [d3,sr] = audioread('piano.aac',targetsr,forcemono,starttime,duration);
% subplot(313)
% specgram(d3,512,sr);

